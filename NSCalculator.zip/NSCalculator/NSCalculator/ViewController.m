//
//  ViewController.m
//  NSCalculator
//
//  Created by Admin on 23.10.14.
//  Copyright (c) 2014 Admin. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@property (weak, nonatomic) IBOutlet UITextField *textBox;

@property (strong, nonatomic) IBOutletCollection(UIButton) NSArray *buttons;

@property (strong, nonatomic) IBOutletCollection(UIButton) NSArray *opers;

@property BOOL flagCE;


@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}
- (IBAction)onTouch:(id)sender {
    if (_flagCE)
        _textBox.text = @"";
        
    UIButton* but = (UIButton*)sender;
   _textBox.text=[_textBox.text stringByAppendingString:but.titleLabel.text];
    NSUInteger index = [_textBox.text length]-1;
    NSString *endOfString = [_textBox.text substringFromIndex:index];
    NSComparisonResult result;
    NSRange range = [_textBox.text rangeOfString:@"|"];
    result = [endOfString compare:@"+"];
    _flagCE = NO;
    if (!result)
        if (range.length > 0){
            NSString *left = [_textBox.text substringToIndex:range.location];
            NSString *right = [_textBox.text substringFromIndex:range.location+1];
            NSUInteger idx = [right length]-1;
            right = [right substringToIndex:idx];
            float vr = [right floatValue];
            float vl = [left floatValue];
            float res = vr+vl;
            _textBox.text = [NSString stringWithFormat:@"%.1f",res];
            _flagCE = YES;
        }
        
    result = [endOfString compare:@"-"];
    if (!result)
        if (range.length > 0){
            NSString *left = [_textBox.text substringToIndex:range.location];
            NSString *right = [_textBox.text substringFromIndex:range.location+1];
            NSUInteger idx = [right length]-1;
            right = [right substringToIndex:idx];
            float vr = [right floatValue];
            float vl = [left floatValue];
            float res = vl-vr;
            _textBox.text = [NSString stringWithFormat:@"%.1f",res];
            _flagCE = YES;
        
        }
    result = [endOfString compare:@"/"];
    if (!result)
        if (range.length > 0){
            NSString *left = [_textBox.text substringToIndex:range.location];
            NSString *right = [_textBox.text substringFromIndex:range.location+1];
            NSUInteger idx = [right length]-1;
            right = [right substringToIndex:idx];
            float vr = [right floatValue];
            float vl = [left floatValue];
            float res = vl/vr;
            _textBox.text = [NSString stringWithFormat:@"%.1f",res];
            _flagCE = YES;
        
        }
    result = [endOfString compare:@"*"];
    if (!result)
        if (range.length > 0){
            NSString *left = [_textBox.text substringToIndex:range.location];
            NSString *right = [_textBox.text substringFromIndex:range.location+1];
            NSUInteger idx = [right length]-1;
            right = [right substringToIndex:idx];
            float vr = [right floatValue];
            float vl = [left floatValue];
            float res = vr*vl;
            _textBox.text = [NSString stringWithFormat:@"%.1f",res];
            _flagCE = YES;
        
        }
    
}

- (IBAction)cePush:(id)sender {
    _textBox.text = @"";
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
